# 9-DIMENSION ADVERSARIAL QA EVALUATION RUBRIC
Used by Layer 3 Adversarial Critic Agent to score generated client deliverables.

| Dimension | Weight | Target Threshold | Evaluation Criteria |
| :--- | :--- | :--- | :--- |
| Technical Accuracy | 15% | >= 90% | Zero hallucinated citations; all URL references verified HTTP 200. |
| Actionability | 20% | >= 90% | Concrete, step-by-step guidance; clear inputs and outputs. |
| Content Quality | 15% | >= 85% | Clear, concise prose; absence of corporate filler. |
| Originality | 10% | >= 85% | Unique operational models, frameworks, and actionable data. |
| Reader Value & ROI | 15% | >= 90% | Demonstrable financial and time-saving commercial return. |
| Implementability | 10% | >= 85% | Feasible for a single-operator without employee headcount. |
| Editorial Polish | 15% | >= 85% | Typographic elegance, clean formatting, professional tone. |
| Total Composite | 100% | >= 85.0% | Required threshold to advance to Layer 4 Human Sovereign Gate. |
