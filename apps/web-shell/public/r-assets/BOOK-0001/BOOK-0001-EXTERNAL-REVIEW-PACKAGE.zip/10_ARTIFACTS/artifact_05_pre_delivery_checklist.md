# PRE-DELIVERY VERIFICATION CHECKLIST (MANDATORY GATE)
**Rule:** Every item must be verified before the Sovereign Operator authorizes client delivery.

---

### Layer 1: Technical & Citation Integrity
- [ ] All URL citations return HTTP 200 OK (zero dead links or 404s).
- [ ] All data tables reconcile mathematically (totals match sum of parts).
- [ ] All quotes retain verbatim fidelity with source link.

### Layer 2: Editorial & Brand Polish
- [ ] Report conforms to client's naming conventions and target scope.
- [ ] Executive summary delivers immediate, non-obvious commercial insights.
- [ ] Zero generic AI buzzwords or filler phrasing detected.

### Layer 3: Physical Document Packaging
- [ ] 6" × 9" PDF renders cleanly with mirrored margins and headers.
- [ ] Zero browser print headers, timestamps, or URLs visible.
- [ ] EPUB3 package passes IDPF validator check.

### Layer 4: Sovereign Sign-off
- [ ] Operator has reviewed executive takeaways.
- [ ] 3-minute executive Loom video recorded.
- [ ] Approval key signed and logged in `approvals/decision_log.json`.
