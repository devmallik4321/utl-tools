# CLIENT ONBOARDING INTAKE BRIEF (FORM SPECIFICATION)
**Service:** Executive B2B Competitor Intelligence Audit (`SRV-COMP-AUDIT-001`)  
**Host Platform:** Tally.so / Typeform Webhook Gateway  
**Validation:** Pydantic `ClientIntakePayload`

---

### Field 1: Client Organization Details (Required)
* **Company Legal Name:** [Text, min 2 chars]
* **Primary Domain / Website:** [URI format, must return HTTP 200]
* **Target ICP (Ideal Customer Profile):** [Text, 20-200 words]

### Field 2: Target Competitors (Required, Exactly 3)
* **Competitor 1 Name & URL:** [Name + URI]
* **Competitor 2 Name & URL:** [Name + URI]
* **Competitor 3 Name & URL:** [Name + URI]

### Field 3: Key Strategic Frictions (Required)
* **Primary Competitive Threat:** (Why are you losing deals?) [Text]
* **Suspected Competitor Pricing:** [Text / Range]

### Field 4: Delivery Preferences (Required)
* **Executive Recipient Name & Title:** [Text]
* **Authorized Delivery Email:** [Email format]
* **Include Executive Video Walkthrough:** [Boolean, default True]
