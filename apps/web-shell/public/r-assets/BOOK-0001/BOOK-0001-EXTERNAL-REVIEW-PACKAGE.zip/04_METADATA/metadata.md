# AMAZON KDP SUBMISSION METADATA REGISTER
**Book ID:** BOOK-0001  
**Publication Status:** CHANGES_REQUIRED (Review Room Locked; Human Decision Required)

---

### Core Publication Payload
* **Title:** The Zero-Employee Agency
* **Subtitle:** Operating a Solo Services Firm with Autonomous AI Teams
* **Author Pseudonym:** Alex Vance
* **Series Title:** Autonomous Enterprise Blueprints (Book #1)
* **Edition:** 3rd Edition (Round-3 Editorial Release)
* **Language:** English (`en`)
* **Word Count:** 18005 words
* **Page Count:** 93 pages (KDP 6" × 9" Trade Paperback)

### Commercial Pricing & Rights
* **Kindle eBook Price:** $9.99 USD
* **Paperback Price:** $19.99 USD
* **Royalty Option:** 70%
* **KDP Select Enrollment:** Recommended & Locked (90-Day Initial Exclusivity Period)

### 7 Amazon Search Keywords
1. `autonomous ai agents`
2. `solopreneur business automation`
3. `zero employee agency`
4. `ai workflows for agencies`
5. `run agency with ai`
6. `multi agent systems guide`
7. `freelance ai productivity`

### Target Amazon Browse Categories
1. `Computers & Technology > Artificial Intelligence`
2. `Business & Money > Small Business & Entrepreneurship > Home Based`

### Amazon Product Description (HTML)
```html
<h3>The definitive operational manual for building, automating, and scaling a high-margin client services business with zero employees.</h3>
<p>For decades, the path to scaling an agency followed an unyielding formula: sign clients, hit personal capacity, hire employees, manage payroll, juggle interpersonal friction, and watch profit margins collapse from 80% down to 15%.</p>
<p><strong>Today, that model is obsolete.</strong></p>
<p>In <em>The Zero-Employee Agency</em>, systems architect and autonomous operator Alex Vance reveals the exact architectural blueprint, technical guardrails, and deterministic workflows required to operate a six-figure client services firm powered entirely by autonomous AI teams under sovereign human governance.</p>
<h4>What You Will Discover Inside:</h4>
<ul>
<li><strong>The 4-Layer Autonomous Architecture:</strong> Ingestion, DAG planning, tool execution harnesses (Playwright/LiteLLM), and adversarial verification.</li>
<li><strong>The 14-Day Zero-Employee Blueprint:</strong> An exact, day-by-day sequence from Day 0 suitability through Day 14 pilot close.</li>
<li><strong>The Complete Resource Stack:</strong> 14 tool categories evaluated with selection criteria and lean Minimum Viable Setups.</li>
<li><strong>Real Project Walkthrough:</strong> The 10-stage lifecycle of an actual B2B competitor intelligence engagement.</li>
<li><strong>When Things Go Wrong:</strong> 15 field failure modes, the 6-step recovery protocol, and non-negotiable human escalation thresholds.</li>
<li><strong>Realistic Unit Economics:</strong> Grounded financial models (EHR, CAC, contribution margin, break-even) with zero exaggerated hype.</li>
<li><strong>Production Artifacts:</strong> Drop-in YAML agent contracts, JSON task schemas, client intake forms, and delivery checklists.</li>
</ul>
<p>Whether you are a solo consultant, an independent engineer, or an exhausted agency owner looking to strip away payroll bloat, this volume is your operational field manual.</p>
```

### AI Content Disclosure
* **Classification:** ASSISTED_STRUCTURING_AND_LINTING
* **Disclosure Required:** Yes (Amazon KDP mandatory declaration)
* **Declaration Statement:** Core concepts, operational workflows, architectural schemas, unit economic models, and qualitative guidelines were developed and curated through human systems engineering. Autonomous AI tools assisted with empirical data gathering, preliminary code snippet generation, and syntactic polish. All claims, formulas, and technical instructions have been verified by human sovereign review.
