# Chapter 6: Real Project Walkthrough: The B2B Competitive Intelligence Audit

Theoretical frameworks become valuable only when tested against the concrete realities of an actual commercial project. To understand how the 4-Layer Autonomous Architecture, the Resource Stack, and the verification protocols function under live client conditions, we now walk through an end-to-end, illustrative client engagement from initial intake to final delivery.

This project is representative of a standard high-ticket engagement in a mature zero-employee agency.

---

### The Engagement Context

* **Client:** *Apex Freight Systems* (Mid-market regional freight forwarding and 3PL logistics provider; $18M annual revenue).
* **Decision Maker:** Marcus Thorne, Chief Commercial Officer.
* **Commercial Problem:** Apex is losing mid-market retail shipping contracts to three fast-growing digital competitors (*TransCore Logistics*, *FreightBridge Global*, and *Vanguard Freight*). Marcus Thorne suspects the competitors are offering dynamic spot pricing and volume rebate structures, but his sales team lacks empirical evidence to counter-position during enterprise negotiations.
* **Service Purchased:** *The Comprehensive B2B Competitor Intelligence & Vulnerability Audit* (Service Code: `SRV-COMP-AUDIT-001`).
* **Contract Value:** **$1,950.00 USD** (50% deposit paid upon intake: $975; balance due on delivery).
* **Delivery SLA:** 5 business days (Target execution: 48 hours).

---

### The 10-Stage Lifecycle Breakdown

![Figure 6: Apex Freight Engagement Lifecycle](images/diagram_06_apex_freight_lifecycle.png)


Every stage of the engagement is governed by an explicit operational contract:
`INPUT` → `PROCESS` → `OUTPUT` → `FAILURE MODES` → `HUMAN GATE`.

```
+---------------------------------------------------------------------------------------+
|                    THE 10 STAGES OF AUTONOMOUS CLIENT FULFILLMENT                     |
+----+----------------------------+-----------------------------------------------------+
| #  | Stage Name                 | Core Operational Transformation                     |
+----+----------------------------+-----------------------------------------------------+
| 1  | Client Intake              | Tally form webhook ──▶ Validated client_brief.json  |
| 2  | Requirements Formulation   | Brief ──▶ Task Decomposition Graph (DAG)            |
| 3  | Research & Harvesting      | Playwright & Tavily ──▶ Raw competitor scrapes      |
| 4  | Source Extraction & Clean  | HTML / PDF ──▶ Structured evidence snippets         |
| 5  | Agent Analysis & Synthesis | Model cross-examination ──▶ Pricing & gap matrix    |
| 6  | Human Review Gate 1        | Operator reviews strategic narrative & direction    |
| 7  | Automated QA & Linting     | Linters check HTTP 200, math parity, schema         |
| 8  | Executive Packaging        | Jinja2 ──▶ Headless Chrome ──▶ 6x9 PDF Monograph    |
| 9  | Client Delivery            | Portal upload + 3-minute personalized Loom video    |
| 10 | Revision & Final Signoff   | 7-day review window ──▶ Balance collection ($975)   |
+----+----------------------------+-----------------------------------------------------+
```

---

#### Stage 1: Client Intake & Onboarding
* **Input:** Client completes structured Tally intake form specifying target competitors (`transcorelogistics.com`, `freightbridgeglobal.com`, `vanguardfreight.com`), primary shipping lanes of concern (Chicago–Dallas, LA–Chicago), and key service differentiators.
* **Process:** Webhook hits agency endpoint. Pydantic validator checks required fields, validates URLs, and registers engagement in SQLite `clients` and `deliverables` tables.
* **Output:** `clients/apex_freight/brief.json` created; deposit confirmed via Stripe webhook.
* **Failure Modes:** Client inputs invalid competitor domain or leaves service lane specifications blank.
* **Human Gate:** If schema validation fails, automated email requests clarification; operator approves intake payload before pipeline trigger.

#### Stage 2: Requirements Formulation & DAG Planning
* **Input:** Validated `brief.json`.
* **Process:** Planning agent decomposes brief into six sequential execution tasks: competitor web harvesting, pricing table extraction, public review sentiment mining, lane benchmark synthesis, vulnerability matrix compilation, and sales battle-card drafting.
* **Output:** `clients/apex_freight/execution_dag.json` with explicit acceptance criteria for each node.
* **Failure Modes:** Planning agent creates redundant tasks or attempts to query private shipping databases that lack public APIs.
* **Human Gate:** Operator inspects DAG in terminal (`python cli.py inspect-dag --client apex_freight`); confirms scope boundaries.

#### Stage 3: Research & Web Data Harvesting
* **Input:** Target URLs and search queries.
* **Process:** Playwright headless scrapers and Tavily API dispatch concurrent queries targeting competitor landing pages, rate calculators, terms of carriage, case studies, and Glassdoor/Indeed employee operational reviews.
* **Output:** 42 raw HTML documents and PDF rate sheets downloaded to `clients/apex_freight/sources/raw/`.
* **Failure Modes:** Competitor website employs aggressive Cloudflare bot challenge; rate calculator hidden behind interactive JavaScript form.
* **Human Gate:** Scraper logs status. If bot block encountered, system alerts operator to capture page snapshot manually via browser extension; execution resumes.

#### Stage 4: Source Collection & Fact Extraction
* **Input:** Raw HTML and PDF files.
* **Process:** Extraction agent executes clean text extraction, stripping navigation headers, tracking scripts, and cookie banners. Formats text into timestamped evidence snippets with exact source URIs and anchors.
* **Output:** `clients/apex_freight/sources/extracted_evidence.json` containing 38 verified evidence nodes.
* **Failure Modes:** Extraction agent mistakes marketing promotional copy ("save up to 40%") for actual base rate card data.
* **Human Gate:** Automated regex linter flags ungrounded discount claims for review.

#### Stage 5: Agent Analysis & Synthesis
* **Input:** Cleaned evidence snippets + client brief.
* **Process:** Analysis agent (Claude 3.5 Sonnet) conducts cross-competitor comparative analysis:
  * Compiles fuel surcharge index across all three competitors.
  * Identifies TransCore's hidden detention billing penalty ($95/hour after 90 minutes).
  * Extracts recurring customer complaints from freight review forums (FreightBridge's weekend dispatch unreliability).
  * Drafts the complete narrative monograph (Executive Summary, Detailed Profiles, Counter-Positioning Playbook).
* **Output:** `clients/apex_freight/intermediate/draft_monograph.md` (9,400 words, 6 comparative tables).
* **Failure Modes:** Agent introduces conversational fluff or repeats boilerplate descriptions of the freight industry.
* **Human Gate:** Draft routed to Stage 6.

#### Stage 6: Human Strategic Review Gate
* **Input:** `draft_monograph.md`.
* **Process:** Sovereign operator reviews the strategic narrative on an internal markdown reader. Evaluates whether the insights directly answer Marcus Thorne's core friction (why Apex is losing retail shipping contracts).
* **Output:** Operator injects two specific qualitative refinements: "Emphasize how Apex's dedicated fleet counters FreightBridge's weekend dispatch failures."
* **Failure Modes:** Operator attempts to manually rewrite large sections instead of prompting the synthesis agent with structured feedback.
* **Human Gate:** Operator signs approval token to trigger revision pass.

#### Stage 7: Automated QA & Technical Linting
* **Input:** Revised `draft_monograph.md`.
* **Process:**
  * `qa_citation_linter.py`: Verifies all 38 embedded citation links return HTTP 200.
  * `qa_table_linter.py`: Validates that mathematical sums in competitor cost comparison tables balance exactly.
  * `qa_typography_linter.py`: Converts straight quotes to typographic curly quotes (`“` and `”`), enforces em-dashes (`—`), and checks header hierarchy.
  * `qa_adversarial_critic.py`: Independent LLM red-teams the findings, scoring the document across 9 quality dimensions.
* **Output:** `clients/apex_freight/evidence/qa_report.json` (Technical QA Score: 100/100; Product Quality Score: 91/100).
* **Failure Modes:** One competitor citation link returned HTTP 404 (competitor moved their pricing page during research).
* **Human Gate:** Linter halts build; operator provides updated link or approves cached archive link.

#### Stage 8: Executive Document Packaging
* **Input:** Linted markdown, brand stylesheets, high-resolution comparison charts.
* **Process:** Jinja2 compiler renders HTML template with CSS Paged Media rules (`size: 6in 9in;`, gutter margin 0.5", running headers, page numbers). Headless Google Chrome compiles the HTML into a print-ready PDF monograph.
* **Output:** `clients/apex_freight/final/APEX-COMPETITOR-AUDIT-2026.pdf` (32 pages, publication-grade layout).
* **Failure Modes:** CSS table wrapping breaks across page boundaries; header overlaps chapter title on first page.
* **Human Gate:** Visual inspection on PDF viewer confirms zero typographic defects.

#### Stage 9: Client Delivery

![Figure 7: Client Delivery Pipeline](images/diagram_07_client_delivery_pipeline.png)
 & Executive Presentation
* **Input:** Final PDF deliverable.
* **Process:**
  * System generates secure, unlisted client download link on agency cloud storage.
  * Operator records a 3-minute personalized Loom video addressed to Marcus Thorne, summarizing the three critical vulnerabilities discovered (specifically highlighting TransCore's detention penalties and FreightBridge's weekend delivery delays).
  * System dispatches professional delivery email with video walkthrough, PDF link, and calendar invitation for executive debrief.
* **Output:** Client receives deliverable within 48 hours of intake (exceeding the 5-day SLA).
* **Failure Modes:** Client email lands in spam folder.
* **Human Gate:** Operator monitors email open telemetry; sends SMS confirmation notification if unread after 12 hours.

#### Stage 10: Revision Window & Final Balance Collection
* **Input:** Client feedback call and written comments.
* **Process:** Client confirms deliverable exceeded expectations; Marcus Thorne requests minor clarification regarding Vanguard's volume tiering. Operator spends 15 minutes updating the specific section, recompiles PDF, and uploads V1.1.
* **Output:** Client signs delivery acceptance; Stripe automated invoice captures remaining $975.00 balance. Total net operator time invested: **3.8 hours**. Net cash profit: **$1,554.65**. Net margin: **79.7%** (EHR: **$409.12/hour**).
* **Failure Modes:** Client requests out-of-scope research on international air freight.
* **Human Gate:** Operator politely points to SLA boundary in initial brief; offers Phase 2 expansion engagement for an additional $1,500.

---

### Diagram 6: Client Delivery Pipeline

```
========================================================================================
                         CLIENT FULFILLMENT PIPELINE TOPOLOGY
========================================================================================

 [ TALLY FORM INTAKE ] ──▶ [ PYDANTIC VALIDATION ] ──▶ [ SQLITE CLIENT REGISTRATION ]
                                                                │
                                                                ▼
 ┌────────────────────────────────────────────────────────────────────────────────────┐
 │ MULTI-AGENT EXECUTION HARNESS                                                      │
 │ ┌───────────────────┐    ┌───────────────────┐    ┌───────────────────┐            │
 │ │ 1. Web Harvester  │───▶│ 2. Fact Extractor │───▶│ 3. Synthesis Agent│            │
 │ │ (Playwright Scrape│    │ (Clean Citations) │    │ (Draft Monograph) │            │
 │ └───────────────────┘    └───────────────────┘    └─────────┬─────────┘            │
 └─────────────────────────────────────────────────────────────┼──────────────────────┘
                                                               │
                                                               ▼
 ┌────────────────────────────────────────────────────────────────────────────────────┐
 │ TWO-STAGE VERIFICATION GATE                                                        │
 │ ┌──────────────────────────────────────┐  ┌──────────────────────────────────────┐ │
 │ │ Stage A: Automated Machine Linters   │  │ Stage B: Adversarial LLM Critic      │ │
 │ │ * HTTP 200 URL Citation Check        │  │ * Red-teams logical conclusions      │ │
 │ │ * Table Arithmetic Balance Check     │  │ * Audits for unsupported claims      │ │
 │ │ * Typographic Entity Check           │  │ * Emits Product Quality Score (0-100)│ │
 │ └──────────────────┬───────────────────┘  └──────────────────┬───────────────────┘ │
 └────────────────────┼─────────────────────────────────────────┼─────────────────────┘
                      │                                         │
                      └────────────────────┬────────────────────┘
                                           │
                                           ▼
 ┌────────────────────────────────────────────────────────────────────────────────────┐
 │ SOVEREIGN OPERATOR GOVERNANCE GATE (ALEX VANCE / OPERATOR)                                        │
 │ * Reviews Auditor Report & Score (Must be Technical 100 / Product >= 85)           │
 │ * Inspects executive takeaways & strategic alignment                               │
 │ * Authorizes document compilation key                                              │
 └─────────────────────────────────────────┬──────────────────────────────────────────┘
                                           │
                                           ▼
 ┌────────────────────────────────────────────────────────────────────────────────────┐
 │ COMPILATION & DELIVERY                                                             │
 │ * Jinja2 Template ──▶ Headless Chrome ──▶ Print-Ready 6x9 PDF Monograph (32 pages) │
 │ * 3-Minute Asynchronous Loom Walkthrough ──▶ Secure Client Delivery Portal         │
 └────────────────────────────────────────────────────────────────────────────────────┘
========================================================================================
```

---

### Diagram 7: First-Client Workflow (Intake to Delivery)

```
========================================================================================
                   FIRST-CLIENT CONVERSATION & DELIVERY TIMELINE
========================================================================================

 DAY 11: PROSPECTING          DAY 12: OUTREACH            DAY 13: DIAGNOSTIC
 ┌─────────────────────┐      ┌─────────────────────┐     ┌─────────────────────┐
 │ Scrape 50 B2B Leads │─────▶│ Send 1-Page Teaser  │────▶│ 20-Min Zoom Review  │
 │ in Freight Niche    │      │ to Marcus Thorne    │     │ of Preliminary Data │
 └─────────────────────┘      └─────────────────────┘     └──────────┬──────────┘
                                                                     │
                                                                     ▼
 DAY 16: RECEPTION            DAY 15: EXECUTION           DAY 14: CLOSE & DEPOSIT
 ┌─────────────────────┐      ┌─────────────────────┐     ┌─────────────────────┐
 │ Deliver 6x9 PDF     │◀─────│ Run 6-Stage Agent   │◀────│ 50% Stripe Deposit  │
 │ + 3-Min Loom Video  │      │ Pipeline + QA Gate  │     │ ($975) Received     │
 └──────────┬──────────┘      └─────────────────────┘     └─────────────────────┘
            │
            ▼
 DAY 18: SIGN-OFF & BALANCE
┌───────────────────────┐
│ Client Approves       │
│ Final $975 Balance    │
│ Net Profit: $1,554.65 │
└───────────────────────┘
========================================================================================
```

---

### Practical Artifact 4: Client Intake Form (Markdown Specification)

This structured intake form is deployed via Tally.so or custom web form to capture required parameters before work begins.

```markdown
# Client Onboarding Brief: Competitor Intelligence Audit

Thank you for partnering with us. To ensure our research team captures exact, high-impact intelligence for your commercial team, please complete the five fields below.

### 1. Primary Organization Profile
* **Company Name:** [Apex Freight Systems]
* **Website URL:** [https://apexfreight.com]
* **Primary Products / Services:** [Full Truckload (FTL) and LTL freight forwarding, warehousing, and temperature-controlled logistics.]
* **Primary Commercial Differentiator:** [Dedicated account management, 99.4% on-time delivery record, guaranteed capacity.]

### 2. Designated Competitors for Forensic Audit
Please specify 3 to 5 direct competitors you frequently encounter in enterprise sales opportunities:
* **Competitor 1 Name & URL:** [TransCore Logistics | https://transcorelogistics.com]
* **Competitor 2 Name & URL:** [FreightBridge Global | https://freightbridgeglobal.com]
* **Competitor 3 Name & URL:** [Vanguard Freight | https://vanguardfreight.com]

### 3. Commercial Pain & Specific Points of Inquiry
What specific rumors, pricing tactics, or feature claims are you hearing from prospects regarding these competitors?
> [TransCore claims to offer spot rates 15% below index, but our sales reps hear their detention and fuel surcharges are punitive. We need exact proof of their fee schedule.]

### 4. Target Decision-Maker Audience for the Report
Who within your organization will use this deliverable?
* [x] Executive Leadership (CEO, CCO, VP Operations)
* [x] Enterprise Sales Representatives (Battle-cards for prospect calls)
* [ ] Product / Service Development Team

### 5. Delivery Confirmation & Primary Stakeholder
* **Designated Executive Sponsor:** Marcus Thorne, CCO
* **Delivery Email:** mthorne@apexfreight.com
```

---

### Practical Artifact 5: Delivery Checklist & Signoff Form

Used by the operator to verify every deliverable element prior to dispatching the final client package.

```markdown
# Pre-Delivery Operational Verification Checklist
**Client:** Apex Freight Systems | **Project ID:** PRJ-APEX-2026-001 | **Date:** 2026-09-08

### Phase 1: Technical & Citation Verification
- [x] All 38 external citation URLs tested via automated HTTP HEAD; 100% returned HTTP 200 OK.
- [x] Pricing comparison tables mathematically reconciled; all fuel surcharge indices balance.
- [x] Zero ungrounded claims or hallucination warning flags in `qa_report.json`.
- [x] PII scrubbed; zero internal agency paths or uncompiled template variables present in text.

### Phase 2: Document Layout & Print Typography
- [x] 6" × 9" Trade layout geometry verified; mirrored margins (Inside: 0.5", Outside: 0.375").
- [x] Running headers alternate correctly (Book title left page, chapter title right page).
- [x] Page numbers sequential starting after table of contents; zero conflicting page counters.
- [x] Total page count verified at 32 pages (exceeds KDP 24-page minimum requirement).
- [x] Cover renders crisply at full resolution (1600x2560) and search thumbnail (156x250).

### Phase 3: Commercial Package Assembly
- [x] Publication-grade PDF compiled: `APEX-COMPETITOR-AUDIT-2026.pdf` (1.4 MB).
- [x] Secondary responsive EPUB3 generated for executive mobile reading: `APEX-COMPETITOR-AUDIT-2026.epub`.
- [x] 3-Minute asynchronous Loom executive walkthrough recorded and tested.
- [x] Sovereign Operator (Alex Vance) signature recorded in SQLite `approvals` ledger.

**Operator Authorization:** `OPERATOR_SOVEREIGN_SIGNOFF_VERIFIED`  
**Execution Timestamp:** `2026-09-08T02:00:00Z`
```

---

### Practical Artifact 6: Revision Request & Scope Control Form

Ensures that client revisions remain within contractual SLA boundaries and do not introduce out-of-scope friction.

```markdown
# Client Revision Request Form: Service SLA Boundary
**Client:** Apex Freight Systems | **SLA Ref:** SRV-COMP-AUDIT-001-REV1

### Permitted Revision Scope Boundary:
* **Included:** Clarification of existing competitor findings, additional depth on agreed service lanes, formatting adjustments for client presentation decks.
* **Excluded (Requires Expansion Contract):** Adding new competitor companies, auditing international markets not in initial brief, conducting bespoke proprietary employee interviews.

### Client Feedback Submission:
* **Section Requiring Clarification:** Chapter 3, Section 2 ("Vanguard Volume Tiering").
* **Specific Inquiry / Revision:** "Please clarify whether Vanguard's 8% volume discount applies to spot freight or only contracted annual lane commitments."
* **Supporting Evidence Provided:** Email thread from prospective retail shipper.

### Operator Resolution & SLA Impact:
* **Resolution:** Ingested Vanguard contractual terms of carriage; added footnote clarifying that discount applies strictly to commitments exceeding 50 loads per month.
* **Hours Required:** 0.25 hours (15 minutes).
* **Delivery:** V1.1 PDF compiled and dispatched within 4 hours.
* **Client Sign-off:** Confirmed; engagement marked `COMPLETED_SUCCESSFUL`.
```