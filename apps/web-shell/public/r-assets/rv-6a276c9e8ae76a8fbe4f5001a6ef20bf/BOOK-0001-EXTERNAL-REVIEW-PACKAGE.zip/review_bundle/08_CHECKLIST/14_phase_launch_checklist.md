# The 14-Phase Zero-Employee Agency Launch Checklist
## Complete Operational Governance & Deployment Verifier

**Document Version:** 2.0.0 (Production Release)  
**Author:** Alex Vance | Autonomous Enterprise Blueprints  
**Epistemic Classification:** `[OPERATIONAL VERIFICATION STANDARD]`  
**Purpose:** Pre-flight and post-flight operational verification for establishing a zero-employee services firm.

---

## Instructions for the Sovereign Operator

Every item in this checklist represents an explicit, deterministic operational milestone. Do not mark an item complete `[x]` without producing the associated tangible evidence artifact in your repository or database.

```
========================================================================================
                                 LAUNCH GATE PHASES
========================================================================================
Phase 1:  Pre-Launch Feasibility & Sovereign Commitment
Phase 2:  Specialized B2B Niche Selection & ICP Definition
Phase 3:  Productized Service Specification & SLA Boundaries
Phase 4:  Deliverable Schema & Acceptance Rubric Architecture
Phase 5:  Task Decomposition & Directed Acyclic Graph (DAG)
Phase 6:  Infrastructure, Model Provisioning & SQLite Setup
Phase 7:  Autonomous Worker Agent Harness (Harvester, Analyst, Synthesizer)
Phase 8:  Automated Linter, Citation & Adversarial QA Suite
Phase 9:  The Golden Sample Production & Sovereign Review
Phase 10: Fault Injection, Chaos Testing & Disaster Recovery
Phase 11: Commercial Packaging, Pricing & Payment Webhooks
Phase 12: Precision Lead Harvesting (Cohort 1: 50 Prospects)
Phase 13: Value-First Asynchronous Teaser Campaign
Phase 14: Pilot Execution, Fulfillment, QA Sign-Off & Balance Capture
========================================================================================
```

---

## Phase-by-Phase Operational Checklist

### Phase 1: Pre-Launch Feasibility & Sovereign Commitment
- [ ] **1.1** Score >= 4/5 on the 5 Zero-Employee Suitability Litmus Tests (Chapter 1).  
  *Evidence:* Completed score recorded in `config/suitability_audit.json`.
- [ ] **1.2** Dedicated local workstation configured with Python 3.11+, Git, and terminal access.  
  *Evidence:* `python --version` >= 3.11; `git --version` verified.
- [ ] **1.3** Canonical Git repository initialized with strict `.gitignore` (excluding `.env`, API keys, client PII).  
  *Evidence:* Initial commit in `zero-employee-agency` repository.
- [ ] **1.4** Formal 90-Day Single-Offer Constraint signed by sovereign operator.  
  *Evidence:* Signed statement in `docs/SOVEREIGN_CHARTER.md`.

---

### Phase 2: Specialized B2B Niche Selection & ICP Definition
- [ ] **2.1** Selected single B2B vertical generating $2M–$30M annual revenue with verified public data.  
  *Evidence:* Niche profile in `config/niche_profile.json`.
- [ ] **2.2** Identified exact decision-maker title (CCO, VP Sales, VP Operations, Managing Director).  
  *Evidence:* ICP definition document in `config/icp_definition.json`.
- [ ] **2.3** Verified at least 200 addressable companies in the target niche.  
  *Evidence:* Prospecting query results saved in `storage/prospects/market_sizing.json`.

---

### Phase 3: Productized Service Specification & SLA Boundaries
- [ ] **3.1** Single productized offer defined (e.g., *The B2B Competitor Intelligence & Vulnerability Audit*).  
  *Evidence:* Service contract spec in `config/service_spec.json`.
- [ ] **3.2** Clear input/output boundaries established (Fixed 5 competitor URLs -> 30-page PDF report).  
  *Evidence:* Scope boundary definition in `config/service_spec.json`.
- [ ] **3.3** SLA turnaround set to 5 business days (internal automation target: < 48 hours).  
  *Evidence:* SLA contract terms documented in `templates/client_sla.yaml`.

---

### Phase 4: Deliverable Schema & Acceptance Rubric Architecture
- [ ] **4.1** Structured 4-part table of contents defined (Exec Summary, Competitor Deep-Dives, Sentiment, Battlecards).  
  *Evidence:* Deliverable outline schema in `templates/deliverable_outline.json`.
- [ ] **4.2** 7-dimension editorial acceptance rubric created (Depth, Actionability, Clarity, Originality, ROI, Feasibility, Polish).  
  *Evidence:* Machine-readable rubric in `templates/acceptance_rubric.yaml`.
- [ ] **4.3** Non-negotiable technical acceptance thresholds established (100% citation links HTTP 200; 100% math balanced).  
  *Evidence:* Linter rules in `config/linter_rules.json`.

---

### Phase 5: Task Decomposition & Directed Acyclic Graph (DAG)
- [ ] **5.1** Ordered 6-node fulfillment DAG mapped with explicit dependency contracts.  
  *Evidence:* DAG architecture in `factory/workflow_dag.json`.
- [ ] **5.2** Input/output JSON schemas defined for every intermediate task node.  
  *Evidence:* Pydantic models in `factory/schemas/task_contracts.py`.
- [ ] **5.3** Terminal QA gate configured as mandatory blocking step before human review.  
  *Evidence:* Gate enforcement logic in `factory/pipeline.py`.

---

### Phase 6: Infrastructure, Model Provisioning & SQLite Setup
- [ ] **6.1** Anthropic API (Claude 3.5 Sonnet) and OpenAI API (GPT-4o) provisioned with balance.  
  *Evidence:* API keys loaded via secure `.env` and verified via test ping.
- [ ] **6.2** Tavily Search API key provisioned and verified for live web extraction.  
  *Evidence:* Search test script returns HTTP 200 and structured results.
- [ ] **6.3** Local SQLite database schema initialized with tables (`clients`, `engagements`, `tasks`, `ledger`).  
  *Evidence:* Database file `storage/agency.db` with validated schema.
- [ ] **6.4** Headless Chromium verified for PDF compilation and scraping.  
  *Evidence:* Playwright headless test screenshot captured.

---

### Phase 7: Autonomous Worker Agent Harness
- [ ] **7.1** Harvester agent (`harvester.py`) scrapes pricing, features, and public reviews into raw JSON.  
  *Evidence:* Test scrape payload saved in `storage/raw_scrapes/test_scrape.json`.
- [ ] **7.2** Analyst agent (`analyst.py`) extracts feature gaps, price tiers, and complaint themes.  
  *Evidence:* Intermediate analysis matrix generated in `storage/test_analysis.json`.
- [ ] **7.3** Synthesizer agent (`synthesizer.py`) compiles formatted monograph draft.  
  *Evidence:* Complete draft markdown produced according to canonical schema.

---

### Phase 8: Automated Linter, Citation & Adversarial QA Suite
- [ ] **8.1** Citation linter verifies 100% of cited URLs return HTTP 200.  
  *Evidence:* Linter output logs 0 broken links in `storage/logs/qa_citation.log`.
- [ ] **8.2** Table math reconciler verifies all mathematical sums and percentages balance.  
  *Evidence:* Math reconciler output logs 0 mismatches in `storage/logs/qa_math.log`.
- [ ] **8.3** Adversarial critic generates 0–100 Product Quality Score (Required: >= 85).  
  *Evidence:* QA evaluation record in `storage/qa_report.json`.
- [ ] **8.4** Automated retry loop triggers re-synthesis if QA score < 85 (max 3 retries).  
  *Evidence:* Retry loop verified via unit test in `tests/test_qa_retry.py`.

---

### Phase 9: The Golden Sample Production & Sovereign Review
- [ ] **9.1** Full automated pipeline executed on representative test target (e.g., Apex Freight Systems).  
  *Evidence:* Complete 30-page PDF monograph generated in `storage/golden_sample/`.
- [ ] **9.2** PDF verified for 6x9 trade layout geometry, mirrored margins, and embedded figures.  
  *Evidence:* PDF visual inspection confirmed by sovereign operator.
- [ ] **9.3** EPUB3 verified via EPUBCheck 5.1.0 with 0 fatals, 0 errors, 0 warnings.  
  *Evidence:* EPUBCheck output log saved in `storage/golden_sample/epubcheck.log`.
- [ ] **9.4** Sovereign operator completes manual line-by-line review and signs golden sample approval.  
  *Evidence:* Signed approval note in `storage/golden_sample/APPROVAL.md`.

---

### Phase 10: Fault Injection, Chaos Testing & Disaster Recovery
- [ ] **10.1** API timeout fault injected; verified backoff retry logic succeeds.  
  *Evidence:* Chaos test log in `storage/logs/chaos_timeout.log`.
- [ ] **10.2** Scraper anti-bot challenge injected; verified fallback search provider.  
  *Evidence:* Scraper fallback log in `storage/logs/chaos_scraper.log`.
- [ ] **10.3** Prompt injection payload injected in mock intake; verified sanitizer strips vector.  
  *Evidence:* Sanitization unit test passing in `tests/test_sanitizer.py`.

---

### Phase 11: Commercial Packaging, Pricing & Payment Webhooks
- [ ] **11.1** Stripe payment link created for $1,950 flat fee (or $975 deposit / $975 balance).  
  *Evidence:* Active Stripe payment link URL verified.
- [ ] **11.2** Tally.so / custom structured intake form deployed and tested.  
  *Evidence:* Live intake form URL capturing 5 competitor URLs and brief.
- [ ] **11.3** Stripe webhook listener tested; automatically logs client record in SQLite upon payment.  
  *Evidence:* Test webhook event successfully registered in `storage/agency.db`.

---

### Phase 12: Precision Lead Harvesting (Cohort 1: 50 Prospects)
- [ ] **12.1** 50 qualified B2B companies in target niche identified ($2M–$30M revenue).  
  *Evidence:* Prospect database in `storage/prospects/cohort_01.json`.
- [ ] **12.2** 50 verified decision-maker work email addresses confirmed.  
  *Evidence:* 100% email validity check verified via ZeroBounce / Hunter.
- [ ] **12.3** 1 specific public friction/vulnerability identified for every prospect.  
  *Evidence:* Research notes populated in `storage/prospects/cohort_01.json`.

---

### Phase 13: Value-First Asynchronous Teaser Campaign
- [ ] **13.1** 50 bespoke 1-page Teaser Audit PDFs generated.  
  *Evidence:* 50 PDF files in `storage/teasers/`.
- [ ] **13.2** 50 value-first emails dispatched from primary corporate domain.  
  *Evidence:* Dispatch timestamp log in `storage/agency.db`.
- [ ] **13.3** Asynchronous 3-minute Loom video teardown recorded for every interested reply.  
  *Evidence:* Loom video URLs logged in `storage/agency.db`.

---

### Phase 14: Pilot Execution, Fulfillment, QA Sign-Off & Balance Capture
- [ ] **14.1** 50% deposit ($975.00) received via Stripe webhook.  
  *Evidence:* Stripe transaction ID logged in `storage/agency.db` financial ledger.
- [ ] **14.2** Autonomous pipeline executed; complete deliverable compiled in < 48 hours.  
  *Evidence:* Pipeline execution execution log in `storage/logs/pipeline_run.log`.
- [ ] **14.3** Technical QA achieves 100/100; Product Quality achieves >= 85/100.  
  *Evidence:* Final `qa_report.json` archived.
- [ ] **14.4** Sovereign operator completes final forensic review and grants delivery key.  
  *Evidence:* Signed approval token in SQLite `deliverables` table.
- [ ] **14.5** Client approves deliverable; automated invoice captures $975.00 balance.  
  *Evidence:* Final payment settled; financial ledger reconciles $1,554.65 net cash profit.
- [ ] **14.6** Client testimonial captured and added to anonymized case study repository.  
  *Evidence:* Client endorsement recorded in `storage/testimonials/`.
